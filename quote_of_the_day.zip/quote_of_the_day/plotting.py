"""Matplotlib charts saved as PNG files."""
from pathlib import Path

from analytics import summarize

REPORT_DIR = Path(__file__).resolve().parent / "reports"


def make_charts(quotes, out_dir=REPORT_DIR):
    """Create category, rating and monthly-trend charts. Returns list of file paths."""
    try:
        import matplotlib
        matplotlib.use("Agg")           # no window needed; saves to file
        import matplotlib.pyplot as plt
    except ImportError:
        print("  ! Matplotlib is not installed. Run: pip install matplotlib")
        return []

    s = summarize(quotes)
    if not s:
        print("  ! No data to plot.")
        return []
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    files = []

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(list(s["by_category"].keys()), list(s["by_category"].values()), color="#2e8b57")
    ax.set_title("Quotes by Category"); ax.set_ylabel("Count")
    fig.autofmt_xdate(); fig.tight_layout()
    p = out_dir / "chart_categories.png"; fig.savefig(p, dpi=120); plt.close(fig); files.append(p)

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar([str(r) for r in s["rating_dist"]], list(s["rating_dist"].values()), color="#e0a800")
    ax.set_title("Rating Distribution"); ax.set_xlabel("Rating"); ax.set_ylabel("Count")
    fig.tight_layout()
    p = out_dir / "chart_ratings.png"; fig.savefig(p, dpi=120); plt.close(fig); files.append(p)

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(list(s["by_month"].keys()), list(s["by_month"].values()), marker="o", color="#1f77b4")
    ax.set_title("Quotes Saved per Month (Trend)"); ax.set_ylabel("Count")
    fig.autofmt_xdate(); fig.tight_layout()
    p = out_dir / "chart_trend.png"; fig.savefig(p, dpi=120); plt.close(fig); files.append(p)
    return files
