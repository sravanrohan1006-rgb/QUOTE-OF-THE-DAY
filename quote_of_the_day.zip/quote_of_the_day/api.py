"""Quote API client with graceful fallback to a local mock cache."""
import json
import random
import urllib.error
import urllib.request
from pathlib import Path

API_URL = "https://zenquotes.io/api/today"
MOCK_CACHE = Path(__file__).resolve().parent / "data" / "mock_cache.json"


def _from_api(timeout):
    req = urllib.request.Request(API_URL, headers={"User-Agent": "QuoteOfTheDay/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    item = payload[0]
    text, author = item["q"].strip(), item["a"].strip()
    if "too many requests" in text.lower():
        raise ValueError("rate limited")
    return {"text": text, "author": author}


def _from_cache():
    with open(MOCK_CACHE, "r", encoding="utf-8") as f:
        return random.choice(json.load(f))


def fetch_quote(timeout=5):
    """Return (quote_dict, origin) where origin is 'api' or 'cache'."""
    try:
        return _from_api(timeout), "api"
    except (urllib.error.URLError, TimeoutError, ValueError, KeyError,
            IndexError, json.JSONDecodeError, OSError):
        try:
            return _from_cache(), "cache"
        except (OSError, json.JSONDecodeError):
            return {"text": "The best way out is always through.", "author": "Robert Frost"}, "cache"
