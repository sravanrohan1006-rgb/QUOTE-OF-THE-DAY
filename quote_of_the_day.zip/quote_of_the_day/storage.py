"""Local persistence (JSON) + CSV import/export with schema checks."""
import csv
import json
import os
import tempfile
from datetime import date
from pathlib import Path

from validation import validate_record

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
QUOTES_FILE = DATA_DIR / "quotes.json"
SAMPLE_FILE = DATA_DIR / "sample_quotes.json"
REQUIRED_KEYS = {"id", "text", "author", "category", "rating", "date_added", "source"}


def _schema_ok(rec):
    return isinstance(rec, dict) and REQUIRED_KEYS.issubset(rec.keys())


def load_quotes(path=QUOTES_FILE):
    """Load quotes; handle missing/corrupt files by creating a clean template."""
    path = Path(path)
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("top-level JSON is not a list")
        good = [r for r in data if _schema_ok(r)]
        skipped = len(data) - len(good)
        if skipped:
            print(f"  ! Skipped {skipped} record(s) that failed schema checks.")
        return good
    except FileNotFoundError:
        save_quotes([], path)          # create clean template
        return []
    except (json.JSONDecodeError, ValueError) as err:
        backup = path.with_suffix(".corrupt.bak")
        try:
            os.replace(path, backup)
        except OSError:
            pass
        print(f"  ! Data file was corrupted ({err}). Backed up to {backup.name}; starting fresh.")
        save_quotes([], path)
        return []


def save_quotes(quotes, path=QUOTES_FILE):
    """Atomic write so a crash never leaves a half-written file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(quotes, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def next_id(quotes):
    return max((q["id"] for q in quotes), default=0) + 1


def make_record(quotes, text, author="Unknown", category="other", rating=3, source="manual"):
    return {
        "id": next_id(quotes),
        "text": text,
        "author": author or "Unknown",
        "category": category,
        "rating": rating,
        "date_added": date.today().isoformat(),
        "source": source,
    }


def is_duplicate(quotes, text):
    t = text.strip().lower()
    return any(q["text"].strip().lower() == t for q in quotes)


def import_csv(csv_path, quotes, error_log_path=None):
    """Bulk import legacy CSV. Returns (added_count, error_lines). Row-by-row validation."""
    added, errors = 0, []
    try:
        with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames or "text" not in [h.strip().lower() for h in reader.fieldnames]:
                return 0, ["File has no 'text' column - expected columns: text,author,category,rating"]
            for line_no, row in enumerate(reader, start=2):
                row = {(k or "").strip().lower(): v for k, v in row.items()}
                rec, errs = validate_record(row)
                if errs:
                    errors.append(f"Row {line_no}: " + "; ".join(errs))
                    continue
                if is_duplicate(quotes, rec["text"]):
                    errors.append(f"Row {line_no}: duplicate quote skipped")
                    continue
                quotes.append(make_record(quotes, rec["text"], rec["author"],
                                          rec["category"], rec["rating"], source="import"))
                added += 1
    except FileNotFoundError:
        return 0, [f"File not found: {csv_path}"]
    except (UnicodeDecodeError, csv.Error) as err:
        return added, [f"Could not read file: {err}"]

    if error_log_path and errors:
        Path(error_log_path).parent.mkdir(parents=True, exist_ok=True)
        Path(error_log_path).write_text("\n".join(errors), encoding="utf-8")
    return added, errors


def export_csv(quotes, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["id", "text", "author", "category", "rating", "date_added", "source"])
        w.writeheader()
        w.writerows(quotes)
